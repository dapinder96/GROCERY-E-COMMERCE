const jwt = require("jsonwebtoken")

const SECRET_KEY = "your_secret_key_here" 

module.exports = {
  SECRET_KEY,
}

